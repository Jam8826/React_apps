export * as authCtrl from "./auth.controller";
export * as imageCtrl from "./image.controller";
export * as homeCtrl from "./home.controller";